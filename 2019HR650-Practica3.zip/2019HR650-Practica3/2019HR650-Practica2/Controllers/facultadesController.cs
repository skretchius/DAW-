﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using _2019HR650_Practica2.Models;

namespace _2019HR650_Practica2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class facultadesController : ControllerBase
    {
        private readonly Class _contexto;

        public facultadesController(Class miContexto)
        {
            this._contexto = miContexto;
        }

        [HttpGet]
        [Route("api/Equipos")]

        public IActionResult Get()
        {
            var EquiposList = _contexto.Equipos;
            {
                IEnumerable<equipos> equiposList = from e in _contexto.Equipos
                                                   select e;
                if (equiposList.Count() > 0)
                {
                    return Ok(equiposList);
                }
                return NotFound();
            }

        }

        [HttpGet]
        [Route("api/equipo/buscarnombre/{buscarNombre}")]
        public IActionResult obtenerNombre(string buscarNombre)
        {
            IEnumerable<equipos> equipoPorNombre = from e in _contexto.Equipos
                                                   where e.nombre.Contains(buscarNombre)
                                                   select e;
            if (equipoPorNombre.Count() > 0)
            {
                return Ok(equipoPorNombre);
            }

            return NotFound();
        }

        [HttpPost]
        [Route("api/equipos")]
        public IActionResult guardarEquipo([FromBody] equipos equipoNuevo)
        {
            try
            {
                IEnumerable<equipos> equipoExiste = from e in _contexto.Equipos
                                                    where e.nombre == equipoNuevo.nombre

                                                    select e;
                if (equipoExiste.Count() == 0)
                {
                    _contexto.Equipos.Add(equipoNuevo);
                    _contexto.SaveChanges();
                    return Ok(equipoNuevo);
                }
                return Ok(equipoExiste);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("api/equipos")]
        public IActionResult updateEquipo([FromBody] equipos equipoAModificar)
        {
            equipos equipoExiste = (from e in _contexto.Equipos
                                    where e.id_equipos == equipoAModificar.id_equipos
                                    select e).FirstOrDefault();
            if (equipoExiste is null)
            {
                return NotFound();
            }

            equipoExiste.nombre = equipoAModificar.nombre;
            equipoExiste.descripcion = equipoAModificar.descripcion;
            equipoExiste.modelo = equipoAModificar.modelo;

            _contexto.Entry(equipoExiste).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(equipoExiste);
        }
    }
}
