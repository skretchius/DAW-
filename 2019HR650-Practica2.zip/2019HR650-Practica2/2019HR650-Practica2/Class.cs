﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using _2019HR650_Practica2.Models;

namespace _2019HR650_Practica2
{
    public class Class : DbContext
    {
        public Class(DbContextOptions<Class> options) : base(options)
        {

        }

        public DbSet<equipos> Equipos { get; set; }
    }
}
