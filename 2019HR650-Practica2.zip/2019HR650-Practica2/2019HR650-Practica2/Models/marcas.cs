﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace _2019HR650_Practica2.Models
{
    public class marcas
    {
        [Key]
        public int id_marca { get; set; }
        public string nombre { get; set; }

    }
}
