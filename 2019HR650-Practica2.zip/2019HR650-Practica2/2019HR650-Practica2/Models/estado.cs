﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace _2019HR650_Practica2.Models
{
    public class estado
    {
        [Key]
        public int estado_equipo_id { get; set; }
    }
}
