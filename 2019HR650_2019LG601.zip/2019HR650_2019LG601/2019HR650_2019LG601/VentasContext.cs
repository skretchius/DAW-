﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using _2019HR650_2019LG601.Models;

namespace _2019HR650_2019LG601
{
    public class VentasContext : DbContext
    {
        public VentasContext(DbContextOptions<VentasContext> options) : base(options)
        {

        }

        public DbSet<Clientes> ventas { get; set; }
        public int Id { get; internal set; }
        public int IdDepartamento { get; internal set; }
        public string Nombre { get; internal set; }
    }
}
