﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using _2019HR650_2019LG601.Models;

namespace _2019HR650_2019LG601.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidosController : ControllerBase
    {
        private readonly VentasContext _contexto;

        public PedidosController(VentasContext miContexto)
        {
            this._contexto = miContexto;
        }

        [HttpGet]
        [Route("api/ventas/Consultas")]

        public IActionResult Get()
        {
            var EquiposList = _contexto.ventas;
            {
                IEnumerable<Clientes> equiposList = from e in _contexto.ventas
                                                    select e;
                if (equiposList.Count() > 0)
                {
                    return Ok(equiposList);
                }
                return NotFound();
            }

        }

        [HttpGet]
        [Route("api/ventas/buscarId")]
        public IActionResult obtenerNombre(string buscarNombre)
        {
            IEnumerable<Clientes> equipoPorNombre = from e in _contexto.ventas
                                                    where e.Nombre.Contains(buscarNombre)
                                                    select e;
            if (equipoPorNombre.Count() > 0)
            {
                return Ok(equipoPorNombre);
            }

            return NotFound();
        }

        [HttpPost]
        [Route("api/ventas/guardar")]
        public IActionResult guardarEquipo([FromBody] Clientes equipoNuevo)
        {
            try
            {
                IEnumerable<Clientes> equipoExiste = from e in _contexto.ventas
                                                     where e.Nombre == equipoNuevo.Nombre

                                                     select e;
                if (equipoExiste.Count() == 0)
                {
                    _contexto.ventas.Add(equipoNuevo);
                    _contexto.SaveChanges();
                    return Ok(equipoNuevo);
                }
                return Ok(equipoExiste);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("api/ventas/modificar")]
        public IActionResult updateEquipo([FromBody] VentasContext equipoAModificar)
        {
            Clientes equipoExiste = (from e in _contexto.ventas
                                     where e.Id == equipoAModificar.Id
                                     select e).FirstOrDefault();
            if (equipoExiste is null)
            {
                return NotFound();
            }

            equipoExiste.Id = equipoAModificar.Id;
            equipoExiste.IdDepartamento = equipoAModificar.IdDepartamento;
            equipoExiste.Nombre = equipoAModificar.Nombre;


            _contexto.Entry(equipoExiste).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(equipoExiste);
        }
    }
}
