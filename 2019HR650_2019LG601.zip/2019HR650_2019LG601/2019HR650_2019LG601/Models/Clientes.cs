﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace _2019HR650_2019LG601.Models
{
    public class Clientes
    {
        internal object id;

        [Key]
        public int Id { get; set; }
        public int IdDepartamento { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaNac { get; set; }
    }
}
