﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace _2019HR650_2019LG601.Models
{
    public class Departamentos
    {
        [Key]
        public int id { get; set; }
        public string departamento { get; set; }
    }
}
