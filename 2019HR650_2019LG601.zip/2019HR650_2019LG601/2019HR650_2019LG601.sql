use ventas
go

Select * From Productos